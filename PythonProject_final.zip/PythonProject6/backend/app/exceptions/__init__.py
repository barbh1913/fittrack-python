# Custom exceptions + HTTP error mapping
