# Pydantic schemas + validation
