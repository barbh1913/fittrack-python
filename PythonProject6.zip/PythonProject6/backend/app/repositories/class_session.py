from datetime import datetime
import uuid

from backend.app.models.Trainer import Trainer
from backend.app.models.Member import Member
from backend.app.models.ClassSession import ClassSession
from backend.app.models.Enrollment import Enrollment
from backend.app.models.enums import EnrollmentStatus, SessionStatus
from backend.app.exceptions.exceptions import NotFoundError, DuplicateError, AppError

class db_sessions:
    def __init__(self, db_manager):
        self.SessionLocal = db_manager.SessionLocal

    def create_session(self, title: str, starts_at: datetime, capacity: int, trainer_id: str, status: SessionStatus = SessionStatus.OPEN):
        with self.SessionLocal() as session:
            try:
                trainer = session.query(Trainer).filter(Trainer.id == trainer_id).first()
                if trainer is None:
                    return False

                ses = ClassSession(
                    id=uuid.uuid4().hex[:15],
                    title=title,
                    starts_at=starts_at,
                    capacity=capacity,
                    trainer_id=trainer_id,
                    status=status.value if isinstance(status, SessionStatus) else status  # Store enum value as string
                )

                session.add(ses)
                session.commit()
                return ses   # ✅ היה return s
            except Exception:
                session.rollback()
                return False

    def enroll_member(self, class_session_id: str, member_id: str):
        with self.SessionLocal() as session:
            try:
                cs = session.query(ClassSession).filter(ClassSession.id == class_session_id).first()
                if cs is None:
                    raise NotFoundError("Class session not found")

                member = session.query(Member).filter(Member.id == member_id).first()
                if member is None:
                    raise NotFoundError("Member not found")

                existing = (
                    session.query(Enrollment)
                    .filter(
                        Enrollment.class_session_id == class_session_id,
                        Enrollment.member_id == member_id,
                        Enrollment.status == EnrollmentStatus.REGISTERED.value
                    )
                    .first()
                )
                if existing is not None:
                    raise DuplicateError("Member is already enrolled in this session")

                current_count = (
                    session.query(Enrollment)
                    .filter(
                        Enrollment.class_session_id == class_session_id,
                        Enrollment.status == EnrollmentStatus.REGISTERED.value
                    )
                    .count()
                )
                if current_count >= cs.capacity:
                    # Session is full - add to waiting list instead
                    from backend.app.repositories.waiting_list import db_waiting_list
                    waiting_list_repo = db_waiting_list(self.db_manager)
                    wl_entry = waiting_list_repo.add_to_waiting_list(class_session_id, member_id)
                    # Return a special response indicating waiting list
                    raise AppError(f"Session is full. You have been added to the waiting list at position {wl_entry.position}.")

                enrol = Enrollment(
                    id=uuid.uuid4().hex[:15],
                    class_session_id=class_session_id,
                    member_id=member_id,
                    status=EnrollmentStatus.REGISTERED.value,
                    created_at=datetime.now(),
                    canceled_at=None,
                    cancel_reason=None
                )

                session.add(enrol)
                session.commit()
                return enrol
            except (NotFoundError, DuplicateError, AppError):
                # Re-raise custom exceptions
                session.rollback()
                raise
            except Exception as e:
                session.rollback()
                import logging
                logger = logging.getLogger(__name__)
                logger.error(f"Unexpected error in enroll_member: {str(e)}", exc_info=True)
                raise AppError(f"Failed to enroll member: {str(e)}")

    def cancel_enrollment(self, class_session_id: str, member_id: str, cancel_reason: str = None):
        with self.SessionLocal() as session:
            try:
                enrol = (
                    session.query(Enrollment)
                    .filter(
                        Enrollment.class_session_id == class_session_id,
                        Enrollment.member_id == member_id,
                        Enrollment.status == EnrollmentStatus.REGISTERED.value
                    )
                    .first()
                )
                if enrol is None:
                    return False

                enrol.status = EnrollmentStatus.CANCELED.value
                enrol.canceled_at = datetime.now()
                enrol.cancel_reason = cancel_reason
                
                # Promote from waiting list when enrollment is canceled
                from backend.app.repositories.waiting_list import db_waiting_list
                waiting_list_repo = db_waiting_list(self.db_manager)
                waiting_list_repo.promote_from_queue(class_session_id)
                
                session.commit()
                return True
            except Exception:
                session.rollback()
                return False

    def list_participants(self, class_session_id: str):
        with self.SessionLocal() as session:
            rows = (
                session.query(Enrollment, Member)
                .join(Member, Member.id == Enrollment.member_id)
                .filter(Enrollment.class_session_id == class_session_id)
                .all()
            )

            return [
                {
                    "member_id": m.id,
                    "full_name": m.fullname if m else None,
                    "status": enrol.status
                }
                for enrol, m in rows
            ]

    def get_weekly_sessions(self, member_id: str = None):
        """Get all sessions for the current week with participant counts."""
        from datetime import datetime, timedelta
        from backend.app.models.Trainer import Trainer
        from backend.app.models.enums import EnrollmentStatus
        
        with self.SessionLocal() as session:
            # Get start and end of current week (Monday to Sunday)
            today = datetime.now().date()
            days_since_monday = today.weekday()
            week_start = datetime.combine(today - timedelta(days=days_since_monday), datetime.min.time())
            week_end = week_start + timedelta(days=7)
            
            # Query sessions for this week
            sessions = (
                session.query(ClassSession, Trainer)
                .join(Trainer, Trainer.id == ClassSession.trainer_id)
                .filter(
                    ClassSession.starts_at >= week_start,
                    ClassSession.starts_at < week_end,
                    ClassSession.status != SessionStatus.CANCELLED.value
                )
                .order_by(ClassSession.starts_at)
                .all()
            )
            
            result = []
            for cs, trainer in sessions:
                # Count registered participants
                participant_count = (
                    session.query(Enrollment)
                    .filter(
                        Enrollment.class_session_id == cs.id,
                        Enrollment.status == EnrollmentStatus.REGISTERED.value
                    )
                    .count()
                )
                
                # Check if member is enrolled
                is_enrolled = False
                if member_id:
                    enrollment = (
                        session.query(Enrollment)
                        .filter(
                            Enrollment.class_session_id == cs.id,
                            Enrollment.member_id == member_id,
                            Enrollment.status == EnrollmentStatus.REGISTERED.value
                        )
                        .first()
                    )
                    is_enrolled = enrollment is not None
                
                result.append({
                    "id": cs.id,
                    "title": cs.title,
                    "starts_at": cs.starts_at.isoformat() if cs.starts_at else None,
                    "capacity": cs.capacity,
                    "current_participants": participant_count,
                    "status": cs.status,
                    "trainer_id": cs.trainer_id,
                    "trainer_name": trainer.fullname if trainer else None,
                    "is_enrolled": is_enrolled
                })
            
            return result

    def get_trainer_sessions(self, trainer_id: str):
        """Get all sessions for a specific trainer with participant counts."""
        from datetime import datetime, timedelta
        from backend.app.models.enums import EnrollmentStatus, SessionStatus
        
        with self.SessionLocal() as session:
            # Get start of current week (Monday)
            today = datetime.now().date()
            days_since_monday = today.weekday()
            week_start = datetime.combine(today - timedelta(days=days_since_monday), datetime.min.time())
            week_end = week_start + timedelta(days=14)  # Get next 2 weeks
            
            # Query sessions for this trainer
            sessions = (
                session.query(ClassSession)
                .filter(
                    ClassSession.trainer_id == trainer_id,
                    ClassSession.starts_at >= week_start,
                    ClassSession.starts_at < week_end,
                    ClassSession.status != SessionStatus.CANCELLED.value
                )
                .order_by(ClassSession.starts_at)
                .all()
            )
            
            result = []
            for cs in sessions:
                # Count registered participants
                participant_count = (
                    session.query(Enrollment)
                    .filter(
                        Enrollment.class_session_id == cs.id,
                        Enrollment.status == EnrollmentStatus.REGISTERED.value
                    )
                    .count()
                )
                
                result.append({
                    "id": cs.id,
                    "title": cs.title,
                    "starts_at": cs.starts_at.isoformat() if cs.starts_at else None,
                    "capacity": cs.capacity,
                    "current_participants": participant_count,
                    "status": cs.status
                })
            
            return result

    def get_all_sessions(self):
        """Get all sessions with trainer info and participant counts."""
        from backend.app.models.enums import EnrollmentStatus
        
        with self.SessionLocal() as session:
            # Query all sessions
            sessions = (
                session.query(ClassSession, Trainer)
                .join(Trainer, Trainer.id == ClassSession.trainer_id)
                .order_by(ClassSession.starts_at.desc())
                .all()
            )
            
            result = []
            for cs, trainer in sessions:
                # Count registered participants
                participant_count = (
                    session.query(Enrollment)
                    .filter(
                        Enrollment.class_session_id == cs.id,
                        Enrollment.status == EnrollmentStatus.REGISTERED.value
                    )
                    .count()
                )
                
                result.append({
                    "id": cs.id,
                    "title": cs.title,
                    "starts_at": cs.starts_at.isoformat() if cs.starts_at else None,
                    "capacity": cs.capacity,
                    "current_participants": participant_count,
                    "status": cs.status,
                    "trainer_id": cs.trainer_id,
                    "trainer_name": trainer.fullname if trainer else None
                })
            
            return result
