from backend.app.models.Member import Member
import logging

logger = logging.getLogger(__name__)


class db_member:
    def __init__(self, db_manager):
        self.SessionLocal = db_manager.SessionLocal

    def add_member(self, id, fullname, email, phone):
        """Add a new member to the database."""
        session = self.SessionLocal()
        try:
            # Create member directly using ORM model (simpler approach)
            member = Member(
                id=id,
                fullname=fullname,
                email=email,
                phone=phone
            )
            session.add(member)
            session.commit()
            return True
        except Exception as e:
            session.rollback()
            logger.error(f"Failed to add member: {e}", exc_info=True)
            return False
        finally:
            session.close()

    def get_member_by_id(self, id):
        try:
            with self.SessionLocal() as session:
                return session.query(Member).filter(Member.id == id).first()
        except Exception as e:
            logger.error(f"Database error in get_member_by_id: {type(e).__name__}: {str(e)}", exc_info=True)
            raise  # Re-raise to be caught by API endpoint

    def get_all_members(self):
        """Get all members from the database."""
        try:
            with self.SessionLocal() as session:
                return session.query(Member).order_by(Member.id).all()
        except Exception as e:
            logger.error(f"Database error in get_all_members: {type(e).__name__}: {str(e)}", exc_info=True)
            raise

    def update_member(self, id, fullname, email, phone):
        with self.SessionLocal() as session:
            try:
                member = session.query(Member).filter(Member.id == id).first()
                if member is None:
                    logger.warning(f"Member does not exist: {id}")
                    return False
                member.fullname = fullname
                member.email = email
                member.phone = phone
                session.commit()
                return True
            except Exception as e:
                session.rollback()
                logger.error(f"Failed to update member: {e}", exc_info=True)
                return False
