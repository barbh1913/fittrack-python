from datetime import datetime, timedelta
import uuid

from backend.app.models.Member import Member
from backend.app.models.Subscription import Subscription
from backend.app.models.Payment import Payment
from backend.app.models.Checkin import Checkin
from backend.app.models.enums import SubscriptionStatus, CheckinResult, PaymentStatus
from backend.app.exceptions.exceptions import NotFoundError, DuplicateError


def _id15():
    return uuid.uuid4().hex[:15]


class db_checkin:
    def __init__(self, db_manager):
        self.SessionLocal = db_manager.SessionLocal

    def checkin(self, member_id: str):
        """
        Process check-in for a member.
        Returns a Checkin object with result enum (APPROVED or DENIED) and reason.
        """
        now = datetime.now()

        with self.SessionLocal() as session:
            try:
                member = session.query(Member).filter(Member.id == member_id).first()
                if member is None:
                    c = Checkin(
                        id=_id15(),
                        member_id=member_id,
                        created_at=now,
                        result=CheckinResult.DENIED.value,
                        reason="Member not found"
                    )
                    session.add(c)
                    session.commit()
                    return c

                sub = (
                    session.query(Subscription)
                    .filter(
                        Subscription.member_id == member_id,
                        Subscription.status == SubscriptionStatus.ACTIVE.value
                    )
                    .first()
                )

                if sub is None:
                    c = Checkin(
                        id=_id15(),
                        member_id=member_id,
                        created_at=now,
                        result=CheckinResult.DENIED.value,
                        reason="No active subscription"
                    )
                    session.add(c)
                    session.commit()
                    return c

                if now < sub.start_date or now > sub.end_date:
                    c = Checkin(
                        id=_id15(),
                        member_id=member_id,
                        created_at=now,
                        result=CheckinResult.DENIED.value,
                        reason="Subscription expired or not started"
                    )
                    session.add(c)
                    session.commit()
                    return c

                if sub.frozen_until is not None and sub.frozen_until > now:
                    c = Checkin(
                        id=_id15(),
                        member_id=member_id,
                        created_at=now,
                        result=CheckinResult.DENIED.value,
                        reason="Subscription frozen"
                    )
                    session.add(c)
                    session.commit()
                    return c

                if sub.remaining_entries <= 0:
                    c = Checkin(
                        id=_id15(),
                        member_id=member_id,
                        created_at=now,
                        result=CheckinResult.DENIED.value,
                        reason="No remaining entries"
                    )
                    session.add(c)
                    session.commit()
                    return c

                # Check for outstanding debts
                if sub.outstanding_debt > 0:
                    c = Checkin(
                        id=_id15(),
                        member_id=member_id,
                        created_at=now,
                        result=CheckinResult.DENIED.value,
                        reason=f"Outstanding debt: {sub.outstanding_debt}. Please settle your account."
                    )
                    session.add(c)
                    session.commit()
                    return c
                
                # Check for failed payments
                failed_payments = (
                    session.query(Payment)
                    .filter(
                        Payment.subscription_id == sub.id,
                        Payment.status == PaymentStatus.FAILED.value
                    )
                    .count()
                )
                if failed_payments > 0:
                    c = Checkin(
                        id=_id15(),
                        member_id=member_id,
                        created_at=now,
                        result=CheckinResult.DENIED.value,
                        reason="Failed payments detected. Please contact administration."
                    )
                    session.add(c)
                    session.commit()
                    return c
                
                # Check daily entry limit (max 3 entries per day)
                today_start = datetime(now.year, now.month, now.day)
                today_checkins = (
                    session.query(Checkin)
                    .filter(
                        Checkin.member_id == member_id,
                        Checkin.created_at >= today_start,
                        Checkin.result == CheckinResult.APPROVED.value
                    )
                    .count()
                )
                if today_checkins >= 3:
                    c = Checkin(
                        id=_id15(),
                        member_id=member_id,
                        created_at=now,
                        result=CheckinResult.DENIED.value,
                        reason="Daily entry limit reached (3 entries per day)"
                    )
                    session.add(c)
                    session.commit()
                    return c
                
                # Check weekly entry limit (max 15 entries per week)
                week_start = now - timedelta(days=now.weekday())
                week_start = datetime(week_start.year, week_start.month, week_start.day)
                week_checkins = (
                    session.query(Checkin)
                    .filter(
                        Checkin.member_id == member_id,
                        Checkin.created_at >= week_start,
                        Checkin.result == CheckinResult.APPROVED.value
                    )
                    .count()
                )
                if week_checkins >= 15:
                    c = Checkin(
                        id=_id15(),
                        member_id=member_id,
                        created_at=now,
                        result=CheckinResult.DENIED.value,
                        reason="Weekly entry limit reached (15 entries per week)"
                    )
                    session.add(c)
                    session.commit()
                    return c

                # All checks passed - approve check-in
                sub.remaining_entries -= 1

                c = Checkin(
                    id=_id15(),
                    member_id=member_id,
                    created_at=now,
                    result=CheckinResult.APPROVED.value,
                    reason=None
                )

                session.add(c)
                session.commit()
                return c

            except Exception as e:
                session.rollback()
                # Return a denied checkin for unexpected errors
                try:
                    c = Checkin(
                        id=_id15(),
                        member_id=member_id,
                        created_at=now,
                        result=CheckinResult.DENIED.value,
                        reason=f"System error: {str(e)}"
                    )
                    session.add(c)
                    session.commit()
                    return c
                except:
                    # If we can't even create a checkin record, re-raise
                    raise
