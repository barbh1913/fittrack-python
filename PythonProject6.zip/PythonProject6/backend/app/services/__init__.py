# Business logic (waitlist, subscription, check-in)
