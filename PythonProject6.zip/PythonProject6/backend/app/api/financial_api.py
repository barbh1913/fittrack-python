"""
Flask Blueprint for Financial Reports API endpoints.
Implements revenue, debt, and demand reporting.
"""
from flask import Blueprint, request
from http import HTTPStatus
from datetime import datetime, timedelta
import logging

from backend.app.models.Subscription import Subscription
from backend.app.models.Payment import Payment
from backend.app.models.Plan import Plan
from backend.app.models.ClassSession import ClassSession
from backend.app.models.enums import PaymentStatus, SubscriptionStatus
from backend.app.repositories.waiting_list import db_waiting_list
from backend.app.exceptions.exceptions import AppError
from backend.app.utils.response import api_response

logger = logging.getLogger(__name__)


def create_financial_blueprint(db_manager):
    """
    Create and configure the financial reports blueprint.
    
    Args:
        db_manager: SQLManger instance for database access
        
    Returns:
        Blueprint: Configured Flask Blueprint
    """
    bp = Blueprint("financial", __name__, url_prefix="/api/financial")
    SessionLocal = db_manager.SessionLocal

    @bp.get("/revenue")
    def get_revenue_report():
        """
        Get revenue report by month or subscription type.
        
        Query Params:
            - start_date: ISO date string (optional)
            - end_date: ISO date string (optional)
            - group_by: "month" or "plan_type" (default: "month")
        
        Returns:
            200 OK with revenue breakdown
        """
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        group_by = request.args.get('group_by', 'month')

        with SessionLocal() as session:
            try:
                # Build query
                query = (
                    session.query(Payment, Subscription, Plan)
                    .join(Subscription, Subscription.id == Payment.subscription_id)
                    .join(Plan, Plan.id == Subscription.plan_id)
                    .filter(Payment.status == PaymentStatus.PAID.value)
                )

                if start_date:
                    query = query.filter(Payment.paid_at >= datetime.fromisoformat(start_date))
                if end_date:
                    query = query.filter(Payment.paid_at <= datetime.fromisoformat(end_date))

                payments = query.all()

                if group_by == "month":
                    # Group by month
                    revenue_by_month = {}
                    for payment, sub, plan in payments:
                        if payment.paid_at:
                            month_key = payment.paid_at.strftime("%Y-%m")
                            if month_key not in revenue_by_month:
                                revenue_by_month[month_key] = 0
                            revenue_by_month[month_key] += payment.amount

                    return api_response(HTTPStatus.OK, {
                        "success": True,
                        "revenue_by_month": revenue_by_month,
                        "total_revenue": sum(revenue_by_month.values())
                    })
                else:
                    # Group by plan type
                    revenue_by_type = {}
                    for payment, sub, plan in payments:
                        plan_type = plan.plan_type
                        if plan_type not in revenue_by_type:
                            revenue_by_type[plan_type] = 0
                        revenue_by_type[plan_type] += payment.amount

                    return api_response(HTTPStatus.OK, {
                        "success": True,
                        "revenue_by_plan_type": revenue_by_type,
                        "total_revenue": sum(revenue_by_type.values())
                    })

            except Exception as e:
                logger.error(f"Error getting revenue report: {str(e)}", exc_info=True)
                raise AppError(f"Failed to get revenue report: {str(e)}")

    @bp.get("/debts")
    def get_debts_report():
        """
        Get open debts report.
        
        Returns:
            200 OK with list of members with outstanding debts
        """
        with SessionLocal() as session:
            try:
                from backend.app.models.Member import Member
                
                subscriptions_with_debt = (
                    session.query(Subscription, Member)
                    .join(Member, Member.id == Subscription.member_id)
                    .filter(Subscription.outstanding_debt > 0)
                    .all()
                )

                debts = [
                    {
                        "member_id": m.id,
                        "member_name": m.fullname,
                        "subscription_id": sub.id,
                        "outstanding_debt": sub.outstanding_debt,
                        "status": sub.status
                    }
                    for sub, m in subscriptions_with_debt
                ]

                total_debt = sum(d["outstanding_debt"] for d in debts)

                return api_response(HTTPStatus.OK, {
                    "success": True,
                    "debts": debts,
                    "count": len(debts),
                    "total_debt": total_debt
                })

            except Exception as e:
                logger.error(f"Error getting debts report: {str(e)}", exc_info=True)
                raise AppError(f"Failed to get debts report: {str(e)}")

    @bp.get("/demand-metrics")
    def get_demand_metrics():
        """
        Get demand metrics for classes (profitable/overloaded).
        
        Returns:
            200 OK with class demand statistics
        """
        with SessionLocal() as session:
            try:
                from backend.app.models.Enrollment import Enrollment
                from backend.app.models.enums import EnrollmentStatus
                from backend.app.repositories.waiting_list import db_waiting_list
                
                # Get all sessions with enrollment counts
                sessions = (
                    session.query(ClassSession)
                    .all()
                )

                metrics = []
                for cs in sessions:
                    enrollment_count = (
                        session.query(Enrollment)
                        .filter(
                            Enrollment.class_session_id == cs.id,
                            Enrollment.status == EnrollmentStatus.REGISTERED.value
                        )
                        .count()
                    )

                    # Get waiting list count
                    waiting_list_repo = db_waiting_list(db_manager)
                    waiting_entries = waiting_list_repo.get_waiting_list(cs.id)
                    waiting_count = len([e for e in waiting_entries if e["status"] == "WAITING"])

                    utilization = (enrollment_count / cs.capacity * 100) if cs.capacity > 0 else 0

                    metrics.append({
                        "session_id": cs.id,
                        "session_title": cs.title,
                        "capacity": cs.capacity,
                        "enrolled": enrollment_count,
                        "waiting": waiting_count,
                        "utilization_percent": round(utilization, 2),
                        "is_overloaded": waiting_count > 5,
                        "is_profitable": utilization > 80
                    })

                return api_response(HTTPStatus.OK, {
                    "success": True,
                    "metrics": metrics,
                    "count": len(metrics)
                })

            except Exception as e:
                logger.error(f"Error getting demand metrics: {str(e)}", exc_info=True)
                raise AppError(f"Failed to get demand metrics: {str(e)}")

    @bp.get("/high-demand")
    def get_high_demand_sessions():
        """
        Get high-demand sessions with recommendations.
        
        Query Params:
            - min_waiting: int (default: 5)
            - min_waiting_hours: int (default: 24)
        
        Returns:
            200 OK with high-demand sessions and recommendations
        """
        min_waiting = int(request.args.get('min_waiting', 5))
        min_waiting_hours = int(request.args.get('min_waiting_hours', 24))

        try:
            waiting_list_repo = db_waiting_list(db_manager)
            high_demand = waiting_list_repo.detect_high_demand(min_waiting, min_waiting_hours)
            
            return api_response(HTTPStatus.OK, {
                "success": True,
                "high_demand_sessions": high_demand,
                "count": len(high_demand)
            })
        except Exception as e:
            logger.error(f"Error getting high-demand sessions: {str(e)}", exc_info=True)
            raise AppError(f"Failed to get high-demand sessions: {str(e)}")

    return bp
