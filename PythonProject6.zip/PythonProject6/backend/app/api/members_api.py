"""
Flask Blueprint for Member API endpoints.
Implements: Create member, Get member by id, Update member.

This module demonstrates:
- Layer separation: API layer only handles HTTP requests/responses
- Business logic is delegated to Services layer
- Data access is handled by dbhandlers
"""
from flask import Blueprint, request
from http import HTTPStatus
from pydantic import ValidationError
import logging

from backend.app.repositories.member import db_member
from backend.app.exceptions.exceptions import AppError, NotFoundError
from backend.app.schemas.member_schema import MemberCreateRequest, MemberUpdateRequest, MemberResponse
from backend.app.utils.response import api_response

logger = logging.getLogger(__name__)


def create_members_blueprint(db_manager):
    """
    Create and configure the members blueprint.
    
    Args:
        db_manager: SQLManger instance for database access
        
    Returns:
        Blueprint: Configured Flask Blueprint
    """
    bp = Blueprint("members", __name__, url_prefix="/api/members")
    svc = db_member(db_manager)

    @bp.post("")
    def create_member():
        """
        Create a new member.
        
        Request Body:
            - id: str (9 digits)
            - fullname: str
            - email: str (validated with regex)
            - phone: str (validated with regex)
            
        Returns:
            201 Created with member data
        """
        data = request.get_json(silent=True) or {}

        try:
            req = MemberCreateRequest.model_validate(data)
        except ValidationError as e:
            raise AppError(e.errors())

        # Check if member already exists
        existing = svc.get_member_by_id(req.id)
        if existing is not None:
            from backend.app.exceptions.exceptions import DuplicateError
            raise DuplicateError("Member with this ID already exists")

        # Create member
        success = svc.add_member(req.id, req.fullname, req.email, req.phone)
        if not success:
            raise AppError("Failed to create member")

        member = svc.get_member_by_id(req.id)
        if member is None:
            raise AppError("Member created but could not be retrieved")

        res = MemberResponse(
            id=member.id,
            fullname=member.fullname,
            email=member.email,
            phone=member.phone
        )

        return api_response(HTTPStatus.CREATED, {
            "success": True,
            **res.model_dump()
        })

    @bp.get("/<member_id>")
    def get_member(member_id: str):
        """
        Get member by ID.
        
        Args:
            member_id: Member ID (9 digits)
            
        Returns:
            200 OK with member data, or 404 if not found
        """
        try:
            member = svc.get_member_by_id(member_id)
            if member is None:
                raise NotFoundError("Member not found")

            res = MemberResponse(
                id=member.id,
                fullname=member.fullname,
                email=member.email,
                phone=member.phone
            )

            return api_response(HTTPStatus.OK, {
                "success": True,
                **res.model_dump()
            })
        except (NotFoundError, AppError):
            # Re-raise custom exceptions so they're handled by error handlers
            raise
        except Exception as e:
            # Catch any other exceptions (database errors, etc.)
            error_msg = str(e)
            error_type = type(e).__name__
            
            logger.error(f"Error in get_member: {error_type}: {error_msg}", exc_info=True)
            
            # Check if it's a table doesn't exist error
            if "doesn't exist" in error_msg.lower() or "Table" in error_type:
                raise AppError("Database tables not found. Please run 'python seed.py' to create tables and load data.")
            else:
                raise AppError(f"Database error: {error_msg}")

    @bp.get("")
    def list_members():
        """
        Get all members.
        
        Returns:
            200 OK with list of all members
        """
        try:
            members = svc.get_all_members()
            members_list = [
                MemberResponse(
                    id=m.id,
                    fullname=m.fullname,
                    email=m.email,
                    phone=m.phone
                ).model_dump()
                for m in members
            ]
            
            return api_response(HTTPStatus.OK, {
                "success": True,
                "members": members_list,
                "count": len(members_list)
            })
        except Exception as e:
            error_msg = str(e)
            logger.error(f"Error in list_members: {error_msg}", exc_info=True)
            raise AppError(f"Failed to retrieve members: {error_msg}")

    @bp.put("/<member_id>")
    @bp.patch("/<member_id>")
    def update_member(member_id: str):
        """
        Update member information.
        
        Args:
            member_id: Member ID (9 digits)
            
        Request Body (all optional):
            - fullname: str
            - email: str (validated with regex)
            - phone: str (validated with regex)
            
        Returns:
            200 OK with updated member data, or 404 if not found
        """
        data = request.get_json(silent=True) or {}

        try:
            req = MemberUpdateRequest.model_validate(data)
        except ValidationError as e:
            raise AppError(e.errors())

        # Check if member exists
        member = svc.get_member_by_id(member_id)
        if member is None:
            raise NotFoundError("Member not found")

        # Prepare update data (only non-None fields)
        fullname = req.fullname if req.fullname is not None else member.fullname
        email = req.email if req.email is not None else member.email
        phone = req.phone if req.phone is not None else member.phone

        # Update member
        success = svc.update_member(member_id, fullname, email, phone)
        if not success:
            raise AppError("Failed to update member")

        # Get updated member
        updated_member = svc.get_member_by_id(member_id)
        res = MemberResponse(
            id=updated_member.id,
            fullname=updated_member.fullname,
            email=updated_member.email,
            phone=updated_member.phone
        )

        return api_response(HTTPStatus.OK, {
            "success": True,
            **res.model_dump()
        })

    return bp
