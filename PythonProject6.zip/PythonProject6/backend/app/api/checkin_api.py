from flask import Blueprint, request
from http import HTTPStatus
from pydantic import ValidationError

from backend.app.repositories.checkin import db_checkin
from backend.app.exceptions.exceptions import AppError
from backend.app.schemas.checkin_schema import CheckinRequest, CheckinResponse
from backend.app.utils.response import api_response


def create_checkin_blueprint(db_manager):
    bp = Blueprint("checkin", __name__, url_prefix="/api/checkin")
    svc = db_checkin(db_manager)

    @bp.post("")
    def do_checkin():
        data = request.get_json(silent=True) or {}

        try:
            req = CheckinRequest.model_validate(data)
        except ValidationError as e:
            raise AppError(e.errors())

        # Business logic is handled in db_checkin service layer
        # Returns a Checkin object with result enum (APPROVED or DENIED)
        c = svc.checkin(req.member_id)
        
        if c is None or c is False:
            from backend.app.exceptions.exceptions import AppError
            raise AppError("Check-in failed. Unable to process check-in request.")

        # Ensure result is a valid enum value (it should already be from the service layer)
        from backend.app.models.enums import CheckinResult
        result_value = c.result
        if isinstance(result_value, CheckinResult):
            result_value = result_value.value
        elif result_value not in [e.value for e in CheckinResult]:
            # If somehow we got an invalid value, default to DENIED
            result_value = CheckinResult.DENIED.value

        res = CheckinResponse(result=result_value, reason=c.reason or "")

        return api_response(HTTPStatus.CREATED, {
            "success": True,
            **res.model_dump()
        })

    return bp
