const API_BASE = '/api'

export function formatError(error) {
  if (typeof error === 'string') return error
  if (error.error) return error.error
  if (error.details) return JSON.stringify(error.details, null, 2)
  if (error.message) return error.message
  return 'An unknown error occurred'
}

export async function apiCall(endpoint, method = 'GET', body = null) {
  try {
    const options = {
      method,
      headers: {
        'Content-Type': 'application/json',
      }
    }
    
    if (body) {
      options.body = JSON.stringify(body)
    }
    
    const response = await fetch(`${API_BASE}${endpoint}`, options)
    
    // Check for network errors first
    if (!response) {
      throw {
        error: 'Network error: No response from server',
        details: 'Make sure Flask server is running on http://localhost:5000'
      }
    }
    
    // Read response text once (can only read body once)
    const text = await response.text()
    
    // Handle empty response
    if (!text || text.trim() === '') {
      throw {
        error: 'Empty response from server',
        details: `Flask server may not be running. Start it with: py run.py\nStatus: ${response.status} ${response.statusText}`
      }
    }
    
    // Check if response is actually JSON
    const contentType = response.headers.get('content-type')
    if (!contentType || !contentType.includes('application/json')) {
      // Not JSON response - might be HTML error page
      throw {
        error: `Server returned non-JSON response (${response.status} ${response.statusText})`,
        details: text.substring(0, 200) // First 200 chars
      }
    }
    
    // Try to parse JSON
    let data
    try {
      data = JSON.parse(text)
    } catch (parseError) {
      throw {
        error: 'Invalid JSON response from server',
        details: parseError.message
      }
    }
    
    if (!response.ok) {
      throw data
    }
    
    return data
  } catch (error) {
    // If it's already our formatted error, throw it
    if (error.error || error.details) {
      throw error
    }
    // Otherwise, wrap it
    throw { error: 'Network error: ' + error.message }
  }
}
