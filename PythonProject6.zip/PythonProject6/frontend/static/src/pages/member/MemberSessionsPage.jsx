import React, { useState, useEffect } from 'react'
import { useAuth } from '../../contexts/AuthContext'
import { apiCall, formatError } from '../../utils/api'
import './MemberSessionsPage.css'

function MemberSessionsPage({ showMessage }) {
  const { user } = useAuth()
  const [sessions, setSessions] = useState([])
  const [loading, setLoading] = useState(false)
  const [refreshing, setRefreshing] = useState(false)

  const loadSessions = async () => {
    setRefreshing(true)
    try {
      const result = await apiCall(`/sessions/weekly?member_id=${user.id}`)
      setSessions(result.sessions || [])
    } catch (error) {
      showMessage(formatError(error))
    } finally {
      setRefreshing(false)
    }
  }

  useEffect(() => {
    loadSessions()
  }, [user.id])

  const handleEnroll = async (sessionId) => {
    setLoading(true)
    try {
      await apiCall(`/sessions/${sessionId}/enroll`, 'POST', {
        member_id: user.id
      })
      showMessage('Enrolled successfully!', 'success')
      await loadSessions() // Refresh the list
    } catch (error) {
      showMessage(formatError(error))
    } finally {
      setLoading(false)
    }
  }

  const handleCancel = async (sessionId) => {
    setLoading(true)
    try {
      await apiCall(`/sessions/${sessionId}/cancel`, 'POST', {
        member_id: user.id,
        cancel_reason: null
      })
      showMessage('Enrollment canceled successfully!', 'success')
      await loadSessions() // Refresh the list
    } catch (error) {
      showMessage(formatError(error))
    } finally {
      setLoading(false)
    }
  }

  const formatDateTime = (isoString) => {
    if (!isoString) return 'N/A'
    const date = new Date(isoString)
    return date.toLocaleString('en-US', {
      weekday: 'short',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  const isFull = (session) => {
    return session.current_participants >= session.capacity
  }

  return (
    <div className="member-sessions-page">
      <div className="page-header">
        <h2>Class Sessions - This Week</h2>
        <button onClick={loadSessions} disabled={refreshing} className="btn-refresh">
          {refreshing ? 'Refreshing...' : '🔄 Refresh'}
        </button>
      </div>

      {sessions.length === 0 ? (
        <div className="info-box">
          <p>No sessions available for this week.</p>
        </div>
      ) : (
        <div className="sessions-list">
          {sessions.map((session) => (
            <div key={session.id} className="session-card">
              <div className="session-header">
                <h3>{session.title}</h3>
                <span className={`session-status ${session.status.toLowerCase()}`}>
                  {session.status}
                </span>
              </div>
              
              <div className="session-details">
                <div className="detail-item">
                  <strong>📅 Time:</strong> {formatDateTime(session.starts_at)}
                </div>
                <div className="detail-item">
                  <strong>👤 Trainer:</strong> {session.trainer_name || session.trainer_id}
                </div>
                <div className="detail-item">
                  <strong>👥 Participants:</strong>{' '}
                  <span className={isFull(session) ? 'full' : ''}>
                    {session.current_participants} / {session.capacity}
                  </span>
                </div>
              </div>

              <div className="session-actions">
                {session.is_enrolled ? (
                  <button
                    onClick={() => handleCancel(session.id)}
                    disabled={loading}
                    className="btn-cancel"
                  >
                    {loading ? 'Canceling...' : 'Cancel Enrollment'}
                  </button>
                ) : (
                  <button
                    onClick={() => handleEnroll(session.id)}
                    disabled={loading || isFull(session)}
                    className="btn-enroll"
                  >
                    {loading ? 'Enrolling...' : isFull(session) ? 'Full' : 'Enroll'}
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

export default MemberSessionsPage
