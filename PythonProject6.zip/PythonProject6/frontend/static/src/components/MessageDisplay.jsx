import React from 'react'
import './MessageDisplay.css'

function MessageDisplay({ message }) {
  if (!message.text) return null

  return (
    <div className={`message ${message.type}-message`}>
      {message.text}
    </div>
  )
}

export default MessageDisplay
