# 🚀 How to Run the Project

## Quick Start (Windows)

### Step 1: Install Python Dependencies

**Option A: Use batch file (Recommended)**
```bash
install-requirements.bat
```

**Option B: Manual**
```bash
pip install -r requirements.txt
```

### Step 2: Configure Database

1. Open `config.ini` in a text editor
2. Update these values:
   ```ini
   [database]
   host = localhost
   port = 3306
   database = gym_db
   user = root
   password = YOUR_MYSQL_PASSWORD
   ```

### Step 3: Initialize Database

**Option A: Use batch file (Recommended)**
```bash
run-seed.bat
```

**Option B: Manual**
```bash
python seed.py
```

This will:
- Test database connection
- Create database if it doesn't exist
- Create all tables
- Insert sample data

### Step 4: Install Frontend Dependencies

**Navigate to frontend directory:**
```bash
cd frontend\static
npm install
cd ..\..
```

### Step 5: Build Frontend (Production)

**Option A: Use batch file (Recommended)**
```bash
start-react.bat
```

**Option B: Manual**
```bash
cd frontend\static
npm run build
cd ..\..
```

### Step 6: Start the Server

**Option A: Use batch file (Recommended)**
```bash
start-flask.bat
```

**Option B: Manual**
```bash
python run.py
```

The server will start on: **http://localhost:5000**

### Step 7: Access the Application

1. Open your browser
2. Go to: **http://localhost:5000**
3. Login with default credentials (see below)

---

## Default Login Credentials

After running `seed.py`, you can login with:

**Admin:**
- Role: `Admin`
- ID: `ADMIN001` or `ADMIN002`

**Trainer:**
- Role: `Trainer`
- ID: `TRAINER001`, `TRAINER002`, or `TRAINER003`

**Member:**
- Role: `Member`
- ID: `123456789`, `987654321`, `111222333`, `444555666`, or `777888999`

---

## Development Mode (Optional)

If you want to develop with hot-reload:

### Terminal 1: Start Flask Backend
```bash
python run.py
```

### Terminal 2: Start React Dev Server
```bash
start-dev.bat
```

Or manually:
```bash
cd frontend\static
npm run dev
```

React dev server will run on: **http://localhost:5173**

**Note:** In development mode, React runs on port 5173 and proxies API calls to Flask on port 5000.

---

## Troubleshooting

### Database Connection Failed

1. **Check MySQL is running:**
   - Open Services (services.msc)
   - Find "MySQL" service
   - Make sure it's running

2. **Verify config.ini:**
   - Check `host`, `port`, `user`, `password`, `database`
   - Make sure database name matches

3. **Test connection:**
   ```bash
   python seed.py
   ```
   This will test the connection automatically

### Frontend Not Found

If you get "frontend/static not found":
1. Make sure you ran `remove-old-folders.bat` to move frontend
2. Or manually copy `app/static` to `frontend/static`

### Port Already in Use

If port 5000 is already in use:
1. Close other applications using port 5000
2. Or modify `run.py` to use a different port

### Module Not Found Errors

If you get import errors:
1. Make sure you're in the project root directory
2. Verify `backend/app/` structure exists
3. Reinstall dependencies: `pip install -r requirements.txt`

---

## Complete Command Sequence

For a fresh setup, run these commands in order:

```bash
# 1. Install Python dependencies
install-requirements.bat

# 2. Configure database (edit config.ini manually)

# 3. Initialize database
run-seed.bat

# 4. Install and build frontend
start-react.bat

# 5. Start server
start-flask.bat
```

---

## Project Structure (After Setup)

```
PythonProject6/
├── backend/app/          # All Python code
├── frontend/static/      # React frontend
├── config.ini            # Database config
├── seed.py              # Database seeding
├── run.py               # Server entry point
└── [batch files]        # Automation scripts
```

---

## Next Steps

1. ✅ Database configured and seeded
2. ✅ Frontend built
3. ✅ Server running on http://localhost:5000
4. ✅ Login and explore the application!

For detailed information, see `README.md`.
