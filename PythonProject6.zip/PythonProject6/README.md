# FitTrack Gym Management System

A comprehensive gym management system built with Flask (Python) and React, implementing advanced features including queue management, smart check-in, progress tracking, and financial reporting.

## 📋 Table of Contents

- [Overview](#overview)
- [Project Structure](#project-structure)
- [Architecture & Design](#architecture--design)
- [Workflow & Process Flow](#workflow--process-flow)
- [How to Run](#how-to-run)
- [Solution Design](#solution-design)
- [Features](#features)
- [API Documentation](#api-documentation)
- [OOP Principles](#oop-principles)
- [Technologies Used](#technologies-used)

---

## Overview

FitTrack is a full-stack gym management system designed to handle:
- **Member Management**: Registration, subscriptions, and profile management
- **Class Session Management**: Scheduling, enrollment, and capacity management
- **Queue Management**: Automatic waiting list with priority-based promotion
- **Smart Check-In**: Real-time validation with debt, payment, and entry limit checks
- **Progress Tracking**: Workout performance logging and historical analysis
- **Financial Management**: Revenue tracking, debt management, and demand analytics
- **Role-Based Access**: Admin, Trainer, and Member roles with appropriate permissions

---

## Project Structure

The project follows a **layered architecture** pattern with clear separation of concerns:

```
PythonProject6/
├── backend/                          # Backend application
│   └── app/
│       ├── api/                       # API Layer (Flask Blueprints)
│       │   ├── members_api.py        # Member CRUD operations
│       │   ├── trainers_api.py       # Trainer management
│       │   ├── admins_api.py         # Admin management
│       │   ├── checkin_api.py       # Check-in operations
│       │   ├── class_sessions.py     # Session management
│       │   ├── subscriptions_api.py # Subscription management
│       │   ├── workout_plans_api.py # Workout plan management
│       │   ├── waiting_list_api.py  # Queue management
│       │   ├── progress_api.py      # Progress tracking
│       │   └── financial_api.py     # Financial reports
│       │
│       ├── repositories/              # Data Access Layer
│       │   ├── db_manager.py        # Database connection manager
│       │   ├── member.py             # Member data operations
│       │   ├── trainer.py            # Trainer data operations
│       │   ├── admin.py             # Admin data operations
│       │   ├── checkin.py            # Check-in business logic
│       │   ├── class_session.py     # Session operations
│       │   ├── subscription.py      # Subscription operations
│       │   ├── workout_plan.py      # Workout plan operations
│       │   ├── waiting_list.py      # Queue management logic
│       │   └── progress_tracking.py # Progress logging
│       │
│       ├── models/                   # ORM Models (SQLAlchemy)
│       │   ├── base.py              # SQLAlchemy declarative base
│       │   ├── Person.py            # Abstract base class
│       │   ├── Member.py            # Member entity
│       │   ├── Trainer.py           # Trainer entity
│       │   ├── Admin.py             # Admin entity
│       │   ├── Plan.py              # Subscription plan
│       │   ├── Subscription.py     # Member subscription
│       │   ├── Payment.py           # Payment records
│       │   ├── ClassSession.py      # Class session
│       │   ├── Enrollment.py        # Session enrollment
│       │   ├── Checkin.py           # Check-in records
│       │   ├── WorkoutPlan.py       # Workout plan
│       │   ├── WorkoutItem.py       # Exercise items
│       │   ├── WaitingList.py       # Waiting list entries
│       │   ├── ProgressLog.py      # Progress logs
│       │   └── enums.py             # Status enumerations
│       │
│       ├── schemas/                  # Validation Layer (Pydantic)
│       │   ├── member_schema.py     # Member request/response schemas
│       │   ├── trainer_schema.py    # Trainer schemas
│       │   ├── admin_schema.py      # Admin schemas
│       │   ├── checkin_schema.py    # Check-in schemas
│       │   ├── class_session_schema.py # Session schemas
│       │   ├── subscription_schema.py  # Subscription schemas
│       │   └── workout_plan_schema.py  # Workout plan schemas
│       │
│       ├── exceptions/               # Error Handling
│       │   ├── exceptions.py         # Custom exception classes
│       │   └── handlers.py          # Flask error handlers
│       │
│       ├── utils/                    # Utilities
│       │   ├── response.py          # API response formatter
│       │   └── authorization.py    # Role-based access control
│       │
│       └── app.py                    # Flask application factory
│
├── frontend/                         # Frontend application (React)
│   └── static/
│       ├── src/                     # React source code
│       │   ├── pages/               # Page components
│       │   ├── components/          # Reusable components
│       │   ├── contexts/            # React contexts (Auth)
│       │   ├── utils/               # Utility functions
│       │   └── main.jsx             # Entry point
│       ├── dist/                     # Production build (generated)
│       └── package.json             # Node.js dependencies
│
├── app/                              # ⚠️ OLD STRUCTURE - TO BE REMOVED
├── models/                           # ⚠️ OLD STRUCTURE - TO BE REMOVED
├── Schemas/                          # ⚠️ OLD STRUCTURE - TO BE REMOVED
├── Services/                         # ⚠️ OLD STRUCTURE - TO BE REMOVED
└── exceptions/                      # ⚠️ OLD STRUCTURE - TO BE REMOVED
│
├── config.ini                        # Database configuration
├── requirements.txt                  # Python dependencies
├── seed.py                          # Database seeding script
├── run.py                           # Application entry point
└── README.md                        # This file
```

### Layer Responsibilities

1. **API Layer** (`backend/app/api/`)
   - Handles HTTP requests/responses
   - Validates input using Pydantic schemas
   - Delegates business logic to repositories
   - Returns formatted JSON responses

2. **Repository Layer** (`backend/app/repositories/`)
   - Contains business logic
   - Manages database sessions
   - Performs data operations
   - Handles transactions (commit/rollback)

3. **Model Layer** (`backend/app/models/`)
   - Defines database schema (SQLAlchemy ORM)
   - Establishes relationships between entities
   - Enforces data constraints

4. **Schema Layer** (`backend/app/schemas/`)
   - Validates request data
   - Serializes response data
   - Enforces regex patterns and constraints

---

## Architecture & Design

### Design Patterns

1. **Layered Architecture**
   - Clear separation: API → Repository → Model
   - Each layer has a single responsibility
   - Easy to test and maintain

2. **Repository Pattern**
   - Encapsulates data access logic
   - Abstracts database operations
   - Enables easy testing with mock repositories

3. **Factory Pattern**
   - `create_app()` factory function
   - Blueprint factory functions for API endpoints
   - Centralized configuration

4. **Strategy Pattern**
   - Different check-in strategies based on subscription type
   - Priority calculation strategies for queue management

### Database Design

**Entity Relationships:**
```
Person (Abstract)
├── Member
├── Trainer
└── Admin

Member
├── Subscriptions (1:N)
├── Enrollments (1:N)
├── Checkins (1:N)
├── WorkoutPlans (1:N)
└── ProgressLogs (1:N)

Subscription
├── Plan (N:1)
└── Payments (1:N)

ClassSession
├── Trainer (N:1)
├── Enrollments (1:N)
└── WaitingList (1:N)

WorkoutPlan
├── Member (N:1)
├── Trainer (N:1)
├── WorkoutItems (1:N)
└── ProgressLogs (1:N)
```

---

## Workflow & Process Flow

### 1. Application Startup Flow

```
run.py
  ↓
create_app() (backend/app/app.py)
  ↓
1. Load config.ini → Create SQLManger
2. Create Flask app instance
3. Register error handlers
4. Register all API blueprints
5. Configure CORS
6. Return configured Flask app
  ↓
Flask server starts on http://localhost:5000
```

### 2. API Request Flow

```
HTTP Request (e.g., POST /api/checkin)
  ↓
Flask Router → Blueprint (checkin_api)
  ↓
API Endpoint Function (do_checkin())
  ↓
1. Parse JSON request body
2. Validate with Pydantic Schema
   ↓ (if validation fails)
   → Raise AppError → Error Handler → JSON Error Response (422)
   ↓ (if valid)
3. Call Repository Layer (db_checkin.checkin())
   ↓
4. Repository uses SQLManger.SessionLocal() → Database Session
   ↓
5. Execute Business Logic:
   - Check member exists
   - Check subscription status
   - Check remaining entries
   - Check outstanding debt
   - Check payment status
   - Check daily/weekly limits
   ↓
6. Query/Update Database (SQLAlchemy ORM)
   ↓
7. Commit transaction
   ↓
8. Return Model Object
   ↓
9. Convert to Pydantic Response Schema
   ↓
10. Return JSON Response (200/201)
```

### 3. Check-In Process Flow

```
Member attempts check-in
  ↓
1. Validate member exists
   ↓ (if not found)
   → DENIED: "Member not found"
   ↓ (if found)
2. Check active subscription exists
   ↓ (if not found)
   → DENIED: "No active subscription"
   ↓ (if found)
3. Check subscription dates (start_date ≤ now ≤ end_date)
   ↓ (if expired/not started)
   → DENIED: "Subscription expired or not started"
   ↓ (if valid)
4. Check if subscription is frozen
   ↓ (if frozen)
   → DENIED: "Subscription frozen"
   ↓ (if not frozen)
5. Check remaining entries > 0
   ↓ (if 0)
   → DENIED: "No remaining entries"
   ↓ (if > 0)
6. Check outstanding debt
   ↓ (if debt > 0)
   → DENIED: "Outstanding debt: X"
   ↓ (if no debt)
7. Check for failed payments
   ↓ (if failed payments exist)
   → DENIED: "Failed payments detected"
   ↓ (if no failed payments)
8. Check daily entry limit (max 3/day)
   ↓ (if limit reached)
   → DENIED: "Daily entry limit reached"
   ↓ (if under limit)
9. Check weekly entry limit (max 15/week)
   ↓ (if limit reached)
   → DENIED: "Weekly entry limit reached"
   ↓ (if under limit)
10. All checks passed
   ↓
   Decrement remaining_entries
   Create Checkin record (APPROVED)
   ↓
   → APPROVED: Check-in successful
```

### 4. Queue Management Flow

```
Member attempts to enroll in session
  ↓
Check if session has available spots
  ↓ (if full)
  → Add to waiting list
  ↓
Calculate priority score:
  - VIP subscription: 1000 base points
  - Regular subscription: 100 base points
  - Waiting time: +1 point per hour
  ↓
Insert into queue at appropriate position
  ↓
Return position and status (WAITING)
  ↓
[When spot becomes available]
  ↓
Promote first member in queue
  ↓
Set status to ASSIGNED
Set approval_deadline (default: 24 hours)
  ↓
Notify member
  ↓
[Member confirms within deadline]
  ↓
Create Enrollment
Set status to CONFIRMED
  ↓
[Member doesn't confirm within deadline]
  ↓
Set status to EXPIRED
Promote next member in queue
```

### 5. Progress Tracking Flow

```
Member completes workout
  ↓
Log progress via API
  ↓
Validate:
  - Workout plan belongs to member
  - Workout item belongs to plan
  - No negative values
  - No future dates
  ↓
Create ProgressLog record
  ↓
Store:
  - Sets completed
  - Reps completed
  - Weight used
  - Duration
  - Notes
  ↓
Calculate improvements:
  - Weight increase vs target
  - Reps increase vs target
  - Sets increase vs target
  ↓
Return success response
```

---

## How to Run

### Prerequisites

1. **Python 3.8+**
   ```bash
   python --version  # Should show 3.8 or higher
   ```

2. **MySQL Server**
   - Install MySQL from https://dev.mysql.com/downloads/mysql/
   - Ensure MySQL service is running

3. **Node.js and npm** (for React frontend)
   ```bash
   node --version
   npm --version
   ```

---

## Database Configuration

### Local Database Environment Setup

The project uses MySQL as the database system. All database connection settings are configured in the `config.ini` file located in the project root directory.

#### Configuration File Location

The database configuration file is located at:
```
PythonProject6/config.ini
```

#### Configuration Parameters

The `config.ini` file contains the following MySQL connection parameters:

```ini
[mysql]
host = localhost
port = 3306
database = gym_db
user = root
password = your_password_here
```

#### How to Change Database Connection Details

**1. Server Host Name (host)**

The `host` parameter specifies the MySQL server address.

- **Default**: `localhost` (for local MySQL installation)
- **For remote server**: Replace with the server's IP address or hostname
- **Examples**:
  ```ini
  host = localhost          # Local MySQL server
  host = 192.168.1.100      # Remote server IP
  host = mysql.example.com  # Remote server hostname
  ```

**2. Database Username (user)**

The `user` parameter specifies the MySQL username for authentication.

- **Default**: `root` (MySQL root user)
- **For custom user**: Replace with your MySQL username
- **Examples**:
  ```ini
  user = root           # MySQL root user
  user = gym_admin      # Custom MySQL user
  user = myuser         # Your MySQL username
  ```

**3. Database Password (password)**

The `password` parameter specifies the MySQL password for the specified user.

- **Important**: Replace `your_password_here` with your actual MySQL password
- **Security Note**: Never commit `config.ini` with real passwords to version control
- **Examples**:
  ```ini
  password = mypassword123     # Simple password
  password = MyP@ssw0rd!      # Complex password with special characters
  password =                  # Empty password (not recommended)
  ```

**4. Database Name (database)**

The `database` parameter specifies the name of the database to use.

- **Default**: `gym_db`
- **Auto-Creation**: The database will be automatically created if it doesn't exist
- **Custom Name**: You can change this to any valid MySQL database name
- **Examples**:
  ```ini
  database = gym_db           # Default database name
  database = fittrack_db      # Custom database name
  database = gym_management   # Alternative name
  ```

**5. Port Number (port)**

The `port` parameter specifies the MySQL server port.

- **Default**: `3306` (MySQL default port)
- **Custom Port**: Only change if MySQL is running on a different port
- **Examples**:
  ```ini
  port = 3306    # Default MySQL port
  port = 3307    # Alternative port
  ```

#### Complete Configuration Example

Here's a complete example of a properly configured `config.ini` file:

```ini
[mysql]
host = localhost
port = 3306
database = gym_db
user = root
password = MySecurePassword123
```

#### Step-by-Step Configuration Instructions

1. **Locate the configuration file**
   - Navigate to the project root directory
   - Open `config.ini` in a text editor

2. **Edit connection parameters**
   - Replace `your_password_here` with your actual MySQL root password
   - Modify other parameters if needed (host, user, database name)

3. **Save the file**
   - Save `config.ini` after making changes
   - Ensure the file is saved in the project root directory

4. **Verify MySQL is running**
   - Ensure MySQL service is started on your system
   - On Windows: Check Services or run `net start MySQL`
   - On Linux/Mac: Check with `sudo systemctl status mysql` or `brew services list`

### How to Verify Database Configuration

After configuring `config.ini`, verify that the database connection is working correctly.

#### Method 1: Run the Seed Script (Recommended)

The seed script will automatically test the database connection and create the database if it doesn't exist:

```bash
python seed.py
```

**Expected Output (Success):**
```
🌱 Starting database seeding...
✅ Database connection successful
🗑️  Dropping existing tables...
📋 Creating database tables...
✅ Tables created successfully
📦 Inserting dummy data...
   Creating members...
   ✅ Created 5 members
   ...
✅ Database seeding completed successfully!
```

**If Connection Fails:**
```
❌ Database connection failed!
```

**Common Issues:**
- **"Can't connect to MySQL server"**: MySQL service is not running
- **"Access denied for user"**: Incorrect username or password in `config.ini`
- **"Unknown database"**: This is normal - the database will be created automatically

#### Method 2: Test Connection Programmatically

Create a simple test script to verify the connection:

```python
# test_connection.py
from backend.app.repositories.db_manager import SQLManger

config_path = "config.ini"
db_manager = SQLManger(config_path=config_path)

if db_manager.test_connection():
    print("✅ Database connection successful!")
    print(f"Database: {db_manager.database}")
    print(f"Host: {db_manager.host}")
else:
    print("❌ Database connection failed!")
    print("Please check your config.ini settings")
```

Run the test:
```bash
python test_connection.py
```

#### Method 3: Manual MySQL Connection Test

Test the connection directly using MySQL command line:

```bash
mysql -h localhost -u root -p
```

When prompted, enter your MySQL password. If you can connect successfully, your credentials are correct.

#### Verification Checklist

After configuration, verify:

- [ ] MySQL service is running
- [ ] `config.ini` file exists in project root
- [ ] All parameters in `config.ini` are correct
- [ ] Password matches your MySQL root password
- [ ] Can connect using `python seed.py` without errors
- [ ] Database is created (check with `mysql -u root -p -e "SHOW DATABASES;"`)

---

### Step-by-Step Setup (Complete Guide)

#### Step 1: Initial Project Setup

**1.1. Clone or Download the Project**
```bash
# Navigate to your project directory
cd PythonProject6
```

**1.2. Verify Prerequisites**
```bash
# Check Python version
python --version  # Should be 3.8 or higher

# Check MySQL is installed
mysql --version

# Check Node.js (for frontend)
node --version
npm --version
```

**1.3. Configure Database Connection**

Edit `config.ini` with your MySQL credentials:
```ini
[mysql]
host = localhost
port = 3306
database = gym_db
user = root
password = YOUR_ACTUAL_MYSQL_PASSWORD
```

**Important**: Replace `YOUR_ACTUAL_MYSQL_PASSWORD` with your real MySQL root password.

#### Step 2: Install Python Dependencies

```bash
# Install all required Python packages
pip install -r requirements.txt
```

**Or use the batch file (Windows):**
```bash
install-requirements.bat
```

**Verify Installation:**
```bash
pip list | grep -i flask
pip list | grep -i sqlalchemy
```

#### Step 3: Initialize and Seed Database

**3.1. Run the Database Seeding Script**

This script will:
- Test the database connection
- Create the database if it doesn't exist
- Create all required tables
- Insert sample data for testing

```bash
python seed.py
```

**Or use the batch file (Windows):**
```bash
run-seed.bat
```

**Expected Output:**
```
🌱 Starting database seeding...
✅ Database connection successful
🗑️  Dropping existing tables...
   Dropped table: workout_items
   Dropped table: workout_plans
   ...
📋 Creating database tables...
✅ Tables created successfully
📦 Inserting dummy data...
   Creating members...
   ✅ Created 5 members
   Creating trainers...
   ✅ Created 3 trainers
   Creating admins...
   ✅ Created 2 admins
   Creating subscription plans...
   ✅ Created 5 plans
   Creating subscriptions...
   ✅ Created 3 subscriptions
   Creating payments...
   ✅ Created 2 payments
   Creating class sessions...
   ✅ Created 3 class sessions
   Creating enrollments...
   ✅ Created 3 enrollments
   Creating check-ins...
   ✅ Created 3 check-ins
   Creating workout plans...
   ✅ Created 1 workout plan
   Creating workout items...
   ✅ Created 3 workout items
   Creating waiting list entries...
   ✅ Created 1 waiting list entry
   Creating progress logs...
   ✅ Created 2 progress logs

✅ Database seeding completed successfully!

📊 Summary:
   - Members: 5
   - Trainers: 3
   - Admins: 2
   - Plans: 5
   - Subscriptions: 3
   - Payments: 2
   - Class Sessions: 3
   - Enrollments: 3
   - Check-ins: 3
   - Workout Plans: 1
   - Workout Items: 3
   - Waiting List Entries: 1
   - Progress Logs: 2
```

**3.2. Verify Database Creation**

You can verify the database was created by connecting to MySQL:

```bash
mysql -u root -p
```

Then run:
```sql
SHOW DATABASES;
USE gym_db;
SHOW TABLES;
```

You should see all the tables created:
- `members`
- `trainers`
- `admins`
- `plans`
- `subscriptions`
- `payments`
- `class_session`
- `enrollment`
- `checkin`
- `workout_plans`
- `workout_items`
- `waiting_list`
- `progress_logs`

#### Step 4: Install Frontend Dependencies

```bash
# Navigate to frontend directory
cd frontend/static

# Install Node.js dependencies
npm install
```

**Verify Installation:**
```bash
# Check node_modules exists
ls node_modules
```

#### Step 6: Build Frontend (Production)

```bash
# From frontend/static directory
npm run build
```

**Or use the batch file (Windows, from project root):**
```bash
start-react.bat
```

This creates the `dist/` folder with production-ready React files.

#### Step 7: Start the Application

**6.1. Start Flask Backend Server**

```bash
# From project root directory
python run.py
```

**Or use the batch file (Windows):**
```bash
start-flask.bat
```

**Expected Output:**
```
✅ Database connection successful!
📋 Checking database tables...
✅ Database tables ready
🚀 Starting Flask server on http://localhost:5000
 * Running on http://0.0.0.0:5000
 * Debug mode: on
```

**6.2. Access the Application**

Open your web browser and navigate to:
```
http://localhost:5000
```

You should see the FitTrack login page.

#### Step 8: (Optional) Development Mode

For development with hot-reload:

**Terminal 1 - Flask Backend:**
```bash
python run.py
```

**Terminal 2 - React Dev Server:**
```bash
cd frontend/static
npm run dev
```

React dev server will start on `http://localhost:5173`

---

### Running from Scratch - Quick Reference

**Complete setup in order:**

1. **Install Prerequisites**
   - Python 3.8+
   - MySQL Server
   - Node.js and npm

2. **Configure Database**
   - Edit `config.ini` with MySQL credentials

3. **Install Dependencies**
   ```bash
   pip install -r requirements.txt
   cd frontend/static && npm install && cd ../..
   ```

4. **Initialize Database**
   ```bash
   python seed.py
   ```

5. **Build Frontend**
   ```bash
   cd frontend/static && npm run build && cd ../..
   ```

6. **Start Server**
   ```bash
   python run.py
   ```

7. **Access Application**
   - Open browser: `http://localhost:5000`
   - Login with default credentials (see below)

---

### Default Login Credentials

After running `seed.py`, you can login with these credentials:

**Admin:**
- Role: `Admin`
- ID: `ADMIN001` or `ADMIN002`

**Trainer:**
- Role: `Trainer`
- ID: `TRAINER001`, `TRAINER002`, or `TRAINER003`

**Member:**
- Role: `Member`
- ID: `123456789`, `987654321`, `111222333`, `444555666`, or `777888999`

#### 2. Install Python Dependencies

```bash
pip install -r requirements.txt
```

**Or use the batch file (Windows):**
```bash
install-requirements.bat
```

#### 3. Setup Database

Run the seeding script to create tables and load sample data:
```bash
python seed.py
```

**Or use the batch file (Windows):**
```bash
run-seed.bat
```

This will:
- Create the database if it doesn't exist
- Create all required tables
- Insert sample data (members, trainers, admins, sessions, etc.)

#### 4. Install React Dependencies

```bash
cd frontend/static
npm install
```

#### 5. Build React App (Production)

```bash
cd frontend/static
npm run build
```

**Or use the batch file (Windows):**
```bash
start-react.bat
```

#### 6. Start Flask Server

```bash
python run.py
```

**Or use the batch file (Windows):**
```bash
start-flask.bat
```

The server will start on **http://localhost:5000**

#### 7. (Optional) Development Mode

For development with hot-reload:

**Terminal 1 - Flask:**
```bash
python run.py
```

**Terminal 2 - React Dev Server:**
```bash
cd frontend/static
npm run dev
```

React dev server will start on **http://localhost:5173**

### Default Login Credentials

After running `seed.py`:

- **Admin**: Role `Admin`, ID `ADMIN001` or `ADMIN002`
- **Trainer**: Role `Trainer`, ID `TRAINER001`, `TRAINER002`, or `TRAINER003`
- **Member**: Role `Member`, ID `123456789`, `987654321`, `111222333`, `444555666`, or `777888999`

---

## Solution Design

### Problem Statement

A gym management system needs to handle:
1. Member subscriptions with different types (monthly, yearly, punch-card)
2. Class sessions with capacity limits
3. Fair queue management when sessions are full
4. Smart check-in with multiple validation rules
5. Progress tracking for personalized workout plans
6. Financial management and reporting
7. Role-based access control

### Solution Approach

#### 1. **Layered Architecture**

Separates concerns into distinct layers:
- **API Layer**: HTTP handling, validation
- **Repository Layer**: Business logic, data operations
- **Model Layer**: Data structure, relationships

**Benefits:**
- Easy to test each layer independently
- Clear separation of responsibilities
- Easy to modify without affecting other layers

#### 2. **ORM-Based Data Access**

Uses SQLAlchemy ORM instead of raw SQL:
- Type-safe database operations
- Automatic relationship management
- Database-agnostic (can switch databases easily)
- Built-in transaction management

#### 3. **Enum-Based Status Management**

All statuses use Python Enums:
- Prevents typos and invalid values
- Type-safe status checks
- Clear documentation of valid states
- Enforces encapsulation

#### 4. **Priority-Based Queue System**

Queue management uses a scoring system:
- **VIP members**: Higher priority (1000 base points)
- **Regular members**: Standard priority (100 base points)
- **Waiting time**: Additional points per hour waited

**Algorithm:**
```python
priority_score = base_score + waiting_time_bonus
# Higher score = Higher priority = Lower position number
```

#### 5. **Comprehensive Check-In Validation**

Multi-step validation process:
1. Member existence
2. Subscription status
3. Date validity
4. Frozen status
5. Remaining entries
6. Outstanding debt
7. Payment status
8. Daily limit
9. Weekly limit

**Why this order?**
- Fastest checks first (existence, status)
- Most expensive checks last (database queries for limits)
- Clear error messages for each failure point

#### 6. **Progress Tracking Design**

Stores historical performance data:
- **ProgressLog**: Immutable records of each workout
- **Comparison**: Actual vs target performance
- **Trend Analysis**: Track improvements over time

**Benefits:**
- Members can see their progress
- Trainers can adjust plans based on data
- Historical data for reporting

#### 7. **Financial Management**

Tracks:
- **Revenue**: By month, by plan type
- **Debts**: Outstanding balances per member
- **Demand Metrics**: Class utilization, waiting lists

**Use Cases:**
- Identify profitable classes
- Track member debts
- Make data-driven decisions about capacity

---

## Features

### Core Features

1. **Member Management**
   - Create, read, update members
   - Email and phone validation (regex)
   - Unique email constraint

2. **Subscription Management**
   - Assign subscriptions to members
   - Freeze/unfreeze subscriptions
   - Track remaining entries
   - Automatic status calculation (ACTIVE/FROZEN/EXPIRED)

3. **Class Session Management**
   - Create sessions with capacity limits
   - Enroll members in sessions
   - Cancel enrollments
   - View participants

4. **Check-In System**
   - Real-time validation
   - Multiple validation rules
   - Automatic entry deduction
   - Comprehensive logging

5. **Workout Plans**
   - Create personalized plans
   - Add exercises with sets/reps/weight
   - View plans with trainer information

### Advanced Features

1. **Queue/Waiting List Management**
   - Automatic addition when sessions are full
   - Priority-based positioning (VIP members first)
   - Automatic promotion when spots open
   - Approval deadlines with expiration
   - High-demand detection

2. **Progress Tracking**
   - Log workout performance
   - View progress history
   - Calculate improvements
   - Trainer progress summaries

3. **Financial Management**
   - Revenue reports (by month/plan type)
   - Open debts tracking
   - Demand metrics (utilization, profitability)
   - High-demand session recommendations

4. **Role-Based Authorization**
   - Admin: Full system access
   - Trainer: Own classes and plans only
   - Member: Own data only

---

## API Documentation

### Base URL
```
http://localhost:5000/api
```

### Request/Response Validation

All API endpoints use **Pydantic schemas** for request validation and response serialization:

#### Request Schemas

Every endpoint that accepts data has a dedicated request schema:
- **Create endpoints**: `*CreateRequest` schemas (e.g., `MemberCreateRequest`)
- **Update endpoints**: `*UpdateRequest` schemas (e.g., `MemberUpdateRequest`)
- **Action endpoints**: Specific request schemas (e.g., `CheckinRequest`, `EnrollmentCreateRequest`)

#### Response Schemas

Every endpoint returns data using a dedicated response schema:
- **Entity responses**: `*Response` schemas (e.g., `MemberResponse`, `TrainerResponse`)
- **Action responses**: Specific response schemas (e.g., `CheckinResponse`, `EnrollmentCreateResponse`)

#### Validation Error Handling

When validation fails, the API returns a **422 Unprocessable Entity** response with detailed field-level error information:

**Example Validation Error Response:**
```json
{
  "http": {
    "code": 422,
    "name": "UNPROCESSABLE_ENTITY",
    "message": "Unprocessable Entity"
  },
  "success": false,
  "error": "Validation error",
  "details": [
    {
      "type": "value_error",
      "loc": ["body", "email"],
      "msg": "Value error, Invalid email format. Must be a valid email address.",
      "input": "invalid-email"
    },
    {
      "type": "value_error",
      "loc": ["body", "phone"],
      "msg": "Value error, Invalid phone format.",
      "input": "123"
    }
  ]
}
```

**Validation Features:**
- **Regex validation** for email, phone, ID, and name fields
- **Type validation** for all field types
- **Range validation** for numeric fields (e.g., capacity > 0, weight >= 0)
- **Length validation** for string fields
- **Enum validation** for status fields

**See `SCHEMA_COVERAGE_REPORT.md` for complete schema documentation.**

### Endpoints

#### Members
- `POST /api/members` - Create member
- `GET /api/members/<id>` - Get member by ID
- `PUT /api/members/<id>` - Update member
- `GET /api/members` - List all members

#### Check-In
- `POST /api/checkin` - Check in a member

#### Subscriptions
- `POST /api/subscriptions` - Assign subscription
- `POST /api/subscriptions/<id>/freeze` - Freeze subscription
- `POST /api/subscriptions/<id>/unfreeze` - Unfreeze subscription
- `GET /api/subscriptions/<id>/status` - Get subscription status

#### Class Sessions
- `POST /api/sessions` - Create session
- `POST /api/sessions/<id>/enroll` - Enroll member
- `POST /api/sessions/<id>/cancel` - Cancel enrollment
- `GET /api/sessions/<id>/participants` - List participants
- `GET /api/sessions/weekly` - Get weekly sessions

#### Waiting List
- `POST /api/waiting-list/sessions/<session_id>` - Add to waiting list
- `POST /api/waiting-list/<id>/confirm` - Confirm assignment
- `GET /api/waiting-list/sessions/<session_id>` - View waiting list
- `POST /api/waiting-list/check-expired` - Check expired assignments

#### Progress Tracking
- `POST /api/progress/log` - Log workout progress
- `GET /api/progress/history/<workout_plan_id>` - Get progress history
- `GET /api/progress/trainer-summary` - Trainer progress summary
- `GET /api/progress/member-summary/<member_id>` - Member progress summary

#### Financial Reports
- `GET /api/financial/revenue` - Revenue report
- `GET /api/financial/debts` - Open debts report
- `GET /api/financial/demand-metrics` - Demand metrics
- `GET /api/financial/high-demand` - High-demand sessions

### Response Format

**Success Response:**
```json
{
  "http": {
    "code": 200,
    "name": "OK",
    "message": "OK"
  },
  "success": true,
  "data": { ... }
}
```

**Error Response:**
```json
{
  "http": {
    "code": 404,
    "name": "NOT_FOUND",
    "message": "Not Found"
  },
  "success": false,
  "error": "Member not found"
}
```

---

## OOP Principles

This project demonstrates all three core OOP principles:

### 1. Inheritance

**Example 1: Person Hierarchy**
```python
class Person(Base):
    """Abstract base class for Person entities"""
    id = Column(String(15), primary_key=True)
    fullname = Column(String(100), nullable=False)
    email = Column(String(100), unique=True, nullable=False)
    phone = Column(String(12), nullable=False)

class Member(Person):
    """Member inherits from Person"""
    __tablename__ = "members"
    # Inherits: id, fullname, email, phone
    # Adds: relationships (subscriptions, enrollments, etc.)

class Trainer(Person):
    """Trainer inherits from Person"""
    __tablename__ = "trainers"
    # Inherits: id, fullname, email, phone
    # Adds: relationships (sessions, workout_plans)
```

**Example 2: Exception Hierarchy**
```python
class AppError(Exception):
    """Base exception for all application errors"""
    pass

class NotFoundError(AppError):
    """Raised when a resource is not found"""
    pass

class DuplicateError(AppError):
    """Raised when attempting to create a duplicate resource"""
    pass
```

### 2. Encapsulation

**Example 1: Status Enums**
```python
class SubscriptionStatus(Enum):
    """Encapsulates valid subscription statuses"""
    ACTIVE = "ACTIVE"
    FROZEN = "FROZEN"
    EXPIRED = "EXPIRED"
    BLOCKED = "BLOCKED"

# Status can only be one of these values
# Direct string assignment is prevented
```

**Example 2: Immutable IDs**
```python
class Member(Person):
    id = Column(String(15), primary_key=True)
    # ID is set once during creation
    # No setter method - cannot be modified after creation
```

**Example 3: Controlled Updates**
```python
# Status changes only through service layer
def freeze_subscription(subscription_id, days):
    # Business logic validates before updating
    # Cannot directly set status = "FROZEN"
    # Must go through this method
```

### 3. Polymorphism

**Example 1: Status-Based Behavior**
```python
def checkin(member_id):
    sub = get_active_subscription(member_id)
    
    # Same Subscription object behaves differently based on status
    if sub.status == SubscriptionStatus.ACTIVE.value:
        # Check dates and entries
    elif sub.status == SubscriptionStatus.FROZEN.value:
        # Check frozen_until date
    elif sub.status == SubscriptionStatus.BLOCKED.value:
        # Deny immediately
```

**Example 2: Exception Handling**
```python
try:
    # May raise NotFoundError, DuplicateError, or AppError
    result = service.operation()
except (NotFoundError, DuplicateError, AppError) as e:
    # All exceptions handled polymorphically
    # Each has different HTTP status code
    return error_response(e)
```

**Example 3: Plan Type Behavior**
```python
# Different plan types have different entry limits
if plan.plan_type == PlanType.VIP.value:
    max_entries = 999  # Unlimited
elif plan.plan_type == PlanType.MONTHLY.value:
    max_entries = 20
elif plan.plan_type == PlanType.PUNCH_CARD.value:
    max_entries = 10
```

---

## Technologies Used

### Backend
- **Python 3.8+**: Programming language
- **Flask**: Web framework
- **SQLAlchemy**: ORM for database operations
- **Pydantic**: Data validation and serialization
- **PyMySQL**: MySQL database connector
- **Flask-CORS**: Cross-origin resource sharing

### Frontend
- **React**: UI framework
- **React Router**: Client-side routing
- **Vite**: Build tool and dev server
- **CSS3**: Styling

### Database
- **MySQL**: Relational database management system

### Development Tools
- **Git**: Version control
- **npm**: Node.js package manager
- **pip**: Python package manager

---

## Additional Resources

- **SETUP_GUIDE.md**: Detailed setup instructions
- **IMPLEMENTATION_COMPLETE.md**: Feature implementation status
- **seed.py**: Database seeding script with sample data

---

## License

This project is for educational purposes.

---

## Support

For issues or questions:
1. Check the error messages carefully
2. Verify all prerequisites are installed
3. Ensure MySQL service is running
4. Check `config.ini` has correct credentials
5. Review the setup guide in `SETUP_GUIDE.md`

---

**Built with ❤️ for gym management**
